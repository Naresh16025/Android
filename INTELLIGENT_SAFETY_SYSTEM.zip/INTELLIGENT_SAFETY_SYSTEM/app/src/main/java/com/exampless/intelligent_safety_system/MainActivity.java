package com.exampless.intelligent_safety_system;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSION_REQUEST_SEND_SMS=1;
    private Button btnrsc;
    private Button bt11;
    private Button btne;
    private  MediaPlayer song;
    private Button bt9;
    private Button bt10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btne = (Button) findViewById(R.id.btne);

        btnrsc = (Button) findViewById(R.id.btnrsc);
        bt9=(Button)findViewById(R.id.bt9);
        bt10=(Button)findViewById(R.id.bt10);
        bt11=(Button)findViewById(R.id.bt11);
        btnrsc.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View v) {
                                          Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                                          startActivity(intent);
                                      }
                                  }
        );

        btne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message="I'm in problem,please help me";
                sendSMSMMessage(message);
            }
        });
        bt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 play();
            }
        });
        bt10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stop();
            }
        });
        bt11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message="I reached Safely";
                sendSMSMMessage(message);
            }
        });

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    String message="I reached Safely";

                    sendSMSMMessage(message);
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    String message="I'm in problem please help me!!";

                    sendSMSMMessage(message);
                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }


    public void play(){
        if(song==null) {
            song = MediaPlayer.create(MainActivity.this, R.raw.police);
        }
        song.start();
    }
  public void stop(){
        song.release();
        song=null;
  }

        public void sendSMSMMessage(String mes){

          String number="9676747005";

            if (number.trim().length() > 0) {

                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSION_REQUEST_SEND_SMS );
                } else {
                    String dial = "smsto:" + number;
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(number,null,mes,null,null);
                    Toast.makeText(MainActivity.this, "Message sent", Toast.LENGTH_SHORT).show();

                }

            } else {
                Toast.makeText(MainActivity.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
            }



        }
}
